# ETF Swing Signal Engine + Phone Dashboard

Two parts:
1. **signal_engine.py** — runs on GitHub's free servers every 15 min during market hours, checks TQQQ/SQQQ/SPXL/SPXU against RSI/MACD/Bollinger/volume, and pushes a Pushover alert the moment a BUY or SELL condition triggers. This works even if your phone is off.
2. **dashboard/** — a installable web app (PWA) for your phone home screen that shows the latest signals at a glance, for when you want to check manually.

Not investment advice — this automates the same kind of technical screening you were already doing by hand. Indicators lag and can whipsaw, especially on leveraged ETFs. Treat every alert as "go look," not "go trade."

## 1. Get your API keys

- **Finnhub** (market data, free tier): https://finnhub.io/register → copy your API key
- **Pushover** (you already use this): your existing App Token + User Key

## 2. Create a GitHub repo

1. Create a new **public or private** repo (private is fine, free tier covers Actions minutes either way at this volume).
2. Upload everything in this folder (`signal_engine.py`, `.github/workflows/trading-alerts.yml`, `dashboard/`) preserving the folder structure.
3. Repo → Settings → Secrets and variables → Actions → New repository secret. Add three:
   - `FINNHUB_API_KEY`
   - `PUSHOVER_APP_TOKEN`
   - `PUSHOVER_USER_KEY`
4. Repo → Settings → Actions → General → under "Workflow permissions," select **Read and write permissions** (the workflow commits `state.json`/`latest.json` back to the repo).

The workflow runs automatically on the cron schedule (every 15 min, 9:30am–4pm ET, Mon–Fri). You can also trigger it manually anytime from the Actions tab → "ETF Signal Check" → Run workflow, to test it immediately rather than waiting for the next 15-min tick.

Note: the cron is set for EST (UTC-5). During daylight saving (EDT, UTC-4) it'll fire an hour "late" relative to market open — shift the cron hours in the workflow file by 1 if that matters to you, or just leave it (it'll still catch most of the day).

## 3. Edit the watchlist (optional)

Open `signal_engine.py`, change:
```python
WATCHLIST = ["TQQQ", "SQQQ", "SPXL", "SPXU"]
```
to whatever tickers you want tracked.

## 4. Put the dashboard on your phone

1. Enable GitHub Pages: repo → Settings → Pages → Source: "Deploy from branch" → branch `main`, folder `/dashboard`. Save.
2. After a minute, GitHub gives you a URL like `https://yourname.github.io/your-repo/`. Open it on your phone in Chrome.
3. Chrome menu → **"Add to Home Screen"** / "Install app." Now it's a real installed app icon, opens full-screen, no browser chrome.
4. Open the app → tap the ⚙ in the bottom right → paste your raw feed URL:
   `https://raw.githubusercontent.com/<you>/<repo>/main/latest.json`
   → Save.

The dashboard refreshes every 60 seconds while open. The actual alerts come from Pushover regardless of whether you have the dashboard open — it's just for glancing at current state.

## 5. Tuning signals

Current logic (in `signal_engine.py`, function `evaluate`):
- RSI < 30 → +1 toward BUY, RSI > 70 → +1 toward SELL
- MACD histogram crosses zero → ±1
- Price touches lower/upper Bollinger Band → ±1
- Volume > 1.5x 20-period average → flagged in the alert text (not currently scored)
- Net score ≥ +2 → BUY alert, ≤ -2 → SELL alert

Adjust `RSI_OVERSOLD`/`RSI_OVERBOUGHT`, the score thresholds, or add your own conditions directly in `evaluate()`.

## What this doesn't do

- It doesn't place trades. Robinhood has no public stock/ETF API, so there's no safe way to wire this into automatic execution on Robinhood — you'll still tap buy/sell yourself.
- It's not guaranteed to catch every move — 15-minute candles mean a fast intraday spike between checks could be missed.
